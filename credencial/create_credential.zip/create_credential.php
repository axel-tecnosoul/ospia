<?php
// Crear la imagen usando la imagen base
//$image = imagecreatefrompng('html5.png');
$image = imagecreate(960, 540);

// Asignar el color para el texto
$black_color = imagecolorallocate($image, 0, 0, 0);
// Color de fondo
$background_color = imagecolorallocate($image, 150, 150, 150);
// Color para el cuadro de la foto
$red_color = imagecolorallocate($image, 150, 50, 50);

// Asignar la ruta de la fuente
$font_path = __DIR__.'/arial.ttf';

$title = "EVILNAPSIS SOFTWARE"; // Titulo
$slogan = "\"DESARROLLO DE APPS Y SISTEMAS WEB/MOBILE\""; // Subtitulo / Slogan

$name = "NOMBRE: AGUSTIN RAMOS ESCALANTE"; // Nombre
$puesto = "PUESTO: SENIOR DEVELOPER"; // Puesto
$address_line1 = "DOMICILIO: ESTE ES MI DOMICILIO"; // Domicilio l 1
$address_line2 = "TABASCO, MEXICO, Cp 86500"; // Domicilio l 2
$folio = "FOLIO: ". "123456789"; // Folio

$vigencia = "VIGENCIA: ". "SEPTIEMBRE 2024"; // Vigencia
// Colocar color de fondo
imagefill($image, 0, 0, $background_color);
imagefilledrectangle($image, 50, 350, 200, 175, $red_color); // Rectangulo para la foto
imagettftext($image, 40, 0, 50, 80, $black_color, $font_path, $title); // Colocar el Titulo
imagettftext($image, 15, 0, 60, 100, $black_color, $font_path, $slogan); // Colocar el Slogan

imagettftext($image, 20, 0, 250, 180, $black_color, $font_path, $name); // Colocar el nombre en la imagen
imagettftext($image, 20, 0, 250, 210, $black_color, $font_path, $puesto); // Colocar el puesto en la imagen

imagettftext($image, 20, 0, 250, 260, $black_color, $font_path, $address_line1); // Colocar el domicilio linea 1 en la imagen
imagettftext($image, 20, 0, 250, 290, $black_color, $font_path, $address_line2); // Colocar el domicilio linea 2 en la imagen
imagettftext($image, 20, 0, 250, 320, $black_color, $font_path, $folio); // Colocar el folio en la imagen

imagettftext($image, 20, 0, 250, 370, $black_color, $font_path, $vigencia); // Colocar la vigencia en la imagen

// GUardar la imagen en el servidor
$filename = "credential-".date(" Y-m-d h:i:s").".png";
imagepng($image, $filename);

imagedestroy($image); // Limpiar la memoria
echo "<a href='".$filename."'>$filename</a>"; // Mostrar el enlace para ver la imagen

?>